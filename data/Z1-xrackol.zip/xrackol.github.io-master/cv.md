---
layout: cv
title: Curiculum vitae
permalink: /cv2/
---

<div class="moj_kontajner">

  <div class="cv_datum"><b>Osobné údaje</b></div><div class="cv_info">&nbsp;</div>
  <div class="cv_datum">Meno</div><div class="cv_info">Lukáš</div>
  <div class="cv_datum">Priezvisko</div><div class="cv_info">Račko</div>
  <div class="cv_datum">Vek</div><div class="cv_info">22</div>
  <hr class="post">

  <div class="cv_datum">2013 - súčastnosť</div><div class="cv_info">Práca v Seal IT Services</div>
  <br>
  <div class="cv_datum">2013 - súčastnosť</div><div class="cv_info">Bakalárske štúdium na STU FIIT v odbore Informatika</div>
  <div class="cv_datum">2009 - 2013</div><div class="cv_info">Štúdium na Gymnáziu Antona Bernoláka v Senci</div>
  <div class="cv_datum">2002 - 2009</div><div class="cv_info">Základná škola v Kráľovej pri Senci</div>
  <div class="cv_datum">2000 - 2002</div><div class="cv_info">Základná škola v Hurbanovej Vsi</div>



</div>