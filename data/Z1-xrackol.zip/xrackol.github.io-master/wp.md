---
layout: page
title: Webove publikovanie
permalink: /wp/
---
<b>Zadanie 1:</b> Osobná webová prezentácia na GitHub pages<br/>
<b>Dátum:</b> 13.3.2016<br/>
<b>Popis:</b> Vytvorte webovú prezentáciu (webové sídlo) o sebe. Zamerajte sa jednak na vaše profesné záujmy (napr. projekty, ktoré riešite/riešili ste, čo vás v informatike najviac baví, fascinuje = váš developerský profil) a jednak vaše osobné záujmy, hobby..<br/>
<b>Odkaz na stiahnutie:</b> <a href="../data/Z1-xrackol.zip" target="_blank">{{ "LINK na subor Z1-xrackol.zip" | slugify: 'pretty' }}</a><br/>       
<hr class="post">
